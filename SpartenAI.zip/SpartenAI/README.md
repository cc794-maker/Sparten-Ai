# Sparten AI for Android

A lightweight Android voice and text assistant with Roman Urdu/English command shortcuts, installed app launching, and a device-supported voice language selector. It runs locally and has no AI server or API key. This first version can open common apps and Android screens, search the web, open the dialer, prepare an SMS, and set a timer.

## Build an APK on GitHub

1. Create a GitHub repository and upload the contents of this folder.
2. Push to `main` or `master`, or open **Actions** and run **Build Sparten AI APK**.
3. Download the `SpartenAI-debug-apk` artifact from the completed run. Its file is `app-debug.apk`.
4. Install it on your Android phone. You may need to allow installs from the app used to download the APK.

The workflow builds a debug APK. For Play Store distribution, create and securely manage your own release signing key.

## Commands

Try `open settings`, `YouTube kholo`, `search weather`, `call 03001234567`, `message Hello`, or `set timer 5 minutes`. Tap **Speak** and grant microphone permission for voice input. The app can launch apps shown in the phone launcher. Speech recognition and selectable text-to-speech voices depend on language packs installed on the phone. Selecting a language sets the recognition locale and spoken voice; command understanding and replies currently support English and Roman Urdu/Urdu shortcuts.

## Android call limitations

This app can open the dialer for you to review and place a call. It cannot automatically answer incoming cellular calls or end calls after two seconds. Android only exposes call-answer controls to an app selected by the user as the phone's default dialer; a regular assistant app cannot do this in the background. Android also does not provide ordinary apps a supported way to inject generated assistant speech into the other side of a carrier call.

## Privacy

Command matching is on-device. Voice recognition is provided by the phone's selected recognition service, whose audio handling follows that service's settings. Sparten AI has no backend.
